
class Transaction
  attr_accessor :name, :date, :description, :amount # открываем доступ r/w
  def initialize(v_name, v_date, v_description, v_amount)
    @name        = v_name,        #название
    @date        = v_date         #Дата
    @description = v_description  #описание
    @amount      = v_amount       #сумма
  end
  def to_h
    {
        name: name,
        date: date,
        description: description,
        amount: amount
    }
  end
end


class Account
  attr_accessor :name_account, :currency, :available_balance, :classification, :array_transaction
  def initialize(v_name_account, v_currency, v_available_balance, v_classification)
    @name_account       = v_name_account      #имя
    @currency          = v_currency         #валюта
    @available_balance  = v_available_balance #баланс
    @classification    = v_classification   #природа
    @array_transaction = Array.new         #транзакции
  end
  def to_h
    {
        name_account: name_account,
        currency: currency,
        available_balance: available_balance,
        classification: classification,
        array_transaction: array_transaction.map(&:to_h)
    }
  end
  #Добавить транзакцию
  def add_transaction(v_name, v_date, v_description, v_amount)
    array_transaction << Transaction.new(v_name, v_date, v_description, v_amount)        #push карты
  end
end

def scroll_to_bottom(_browser)
  #скролим вниз сайта чтобы можно было бы подцепить весь список транзакций
  while _browser.text.include?("No more activity")==false
    _browser.scroll.to :bottom
  end
end