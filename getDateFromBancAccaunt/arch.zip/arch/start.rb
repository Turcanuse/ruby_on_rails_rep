#autor: SergheiScepanovschi
#ver 3.8
require 'date'
require 'watir'
require 'nokogiri'
require 'webdrivers'
require 'rubygems'
require 'json'
require_relative 'account'

# добавляем новые элементы массива из JSON hash
array_accaunts = []
browser = Watir::Browser.new :firefox
#WebDriverWait wait = new WebDriverWait(browser, 30//unit time in seconds)
#заходим на сайт
browser.goto "https://demo.bendigobank.com.au/banking/sign_in"

#кликаем на кнопку входа
browser.button(:name => "customer_type").click
#копируем необходимые данные
strct = browser.script(:id => "data").innertext

#Находим данные
pos1 = strct.rindex(/__DATA__/)
pos2 = strct.rindex(/__BOOTSTRAP_I18N__/)
pos1 +=10
pos2 -=69
# Копируем подстроку с данными
strct = strct.slice(pos1,pos2)
#здесь при парсинг JSON
my_hash = JSON.parse(strct)
i=0
#поменять циклы for на each
my_hash["accounts"].map do |item|
  array_accaunts << Account.new(item["name"], item["currentBalance"]["currency"], item["currentBalance"]["value"],item["classification"])
end

TWO_MONTH                  = 60
current_date               = Time.now.strftime('%e %b %Y')
i = 0
browser.elements(:xpath, '//li[@data-semantic="account-item"]').map do |build|


  #скролим вниз
  scroll_to_bottom(browser)

  # Переход по транзакциям
  browser.elements(:xpath, '//li[@data-semantic="activity-item"]').map do |transaction|
    sleep 2
    transaction.scroll.to
    sleep 2
    transaction.click
    sleep 2 # подождём открытия окна с данными о транзакции
    #собираем данные с транзакции
    header_transaction = Nokogiri::HTML(browser.html).css('span[data-semantic="payment-amount"]')
    properties_transaction = Nokogiri::HTML(browser.html).css('nav[class="uilist"] > div[class="uilist__item"]')
    container_attributes = []
    name_transaction = ''
    date_transaction = ''
    description_transaction = ''
    array_labels = ['Pade on', 'Payment Date', 'Description']
    amount_transaction = header_transaction.children.last.text.delete('$')
    name_transaction = Nokogiri::HTML(browser.html).css('div[class="overflow-ellipsis panel__header__label__primary"]')
    puts name_transaction
    puts amount_transaction
    #подцепляем атрибуты транзакции
    #properties_transaction.map do |list_item|
      #label_item = list_item.css('span[class="uilist__item__label"]').text
      #detail_item = list_item.css('span[class="uilist__item__label"] + span[class="uilist__item__detail"]')
      #detail_item = detail_item ? detail_item.text : "None"
      #array_details = [label_item, detail_item]
      #container_attributes.push(array_details)
      #end
    #puts container_attributes
    puts '-' * 48
    browser.back
  end
end

puts '-' * 84
puts array_accaunts.map(&:to_h).to_json
puts '-' * 84

